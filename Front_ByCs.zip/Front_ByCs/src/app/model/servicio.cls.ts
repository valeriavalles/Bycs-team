export class Servicio {
id              :number;     
codServicio     :string ; 
tipoServicio    :string ;
fechaServicio   :Date;
monto           :number; 
obserServicio   :string;
detalleServicio :string; 
departamento    :string;  
ciudad          :string; 
distrito        :string; 
direccion       :string; 
idProfesional   :number;   
idCliente       :number;  
imgUrl          :string;
}