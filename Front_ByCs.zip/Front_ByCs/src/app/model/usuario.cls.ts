export class Usuario {  
    correo     :string ; 
    password   :string ; 
    TipoServicio  :string ; 
    nombres     :string ; 
    apellidos     :string ; 
    estado     :string ; 
    id  : number;
    constructor (){
        
    }
    }