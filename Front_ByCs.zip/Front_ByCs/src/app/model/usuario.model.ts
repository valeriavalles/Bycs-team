
export interface UsuarioModel {

    nombres: string;
    apellidos: string;
    correo: string;
    direccion: string;
    tipousuario: string;
    dni: string;
    numeroceltel: string;
    tiposervicio: string;
    password: string;
}