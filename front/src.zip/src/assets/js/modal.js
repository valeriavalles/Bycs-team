// (function($) {
//   "use strict"; // Start of use strict

  // Smooth scrolling using jQuery easing
  // $('#myModal').on('shown.bs.modal', function () {
  //   $('#myInput').trigger('focus')
  // })
$( document ).ready(function() {
  $('.nav-link').on('click', function(){
    var $this_link = $(this)

    console.log($this_link)
    $('.nav-link').removeClass('active-link')
    $(this).addClass('active-link')

  })
});


// console.log($('.content-wrapper'))
// console.log($('.content-wrapper'))
// console.log('sadasd')
// $('.list-projects').on('click', function(){
//   var $this_link = $(this)

//   console.log('sadasd')
//   // $('.nav-link').removeClass('active-link')
//   // $(this).addClass('active-link')

// })

// for (var key of Object.keys(p)) {
//   console.log(key + " -> " + p[key])
// }
  
// })(jQuery); // End of use strict