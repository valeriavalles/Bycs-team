﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Text;
using ApiRestByCs;
using System.Threading.Tasks;

namespace PruebasUnitariasByCs
{
    //[TestClass]
    class UnitTestRegistrarServicio
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void Test1()
        {
            ApiRestByCs.Dominio.Servicio servicio = new ApiRestByCs.Dominio.Servicio();
            servicio.codServicio = "TES12345";
            servicio.tipoServicio = "Lavanderia";
            servicio.fechaServicio = DateTime.Now;
            servicio.monto = 0;
            servicio.obserServicio = "ok";
            servicio.detalleServicio = "Lavado de sabanas";
            servicio.departamento = "Lima";
            servicio.ciudad = "Lima";
            servicio.distrito = "Jesus Maria";
            servicio.direccion = "Av. los ruiseñores";
            servicio.idProfesional = 14;
            servicio.idCliente = 0;
            servicio.imgUrl = "http://www.industrialwash.com.pe/blog/wp-content/uploads/2017/07/servicio-lavanderia-industrial-preguntas.jpg";
            ApiRestByCs.Controllers.ServiciosController serviciosController = new ApiRestByCs.Controllers.ServiciosController();
            Task<ApiRestByCs.Errores.ServiciosValidator> serviciosValidator = serviciosController.Post(servicio);
            Assert.AreEqual(serviciosValidator.Result.codigomensaje, "99");


        }
    }
}
