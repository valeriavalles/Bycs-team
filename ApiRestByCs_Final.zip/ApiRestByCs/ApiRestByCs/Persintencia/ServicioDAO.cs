﻿using ApiRestByCs.Dominio;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace ApiRestByCs.Persintencia
{
    public class ServicioDAO
    {
      
    private string cadenaconexion = "Data Source=dbdemo.c8sweumaifih.us-east-2.rds.amazonaws.com;initial catalog=bdproyectoSyCs;User ID=admin;Password=Valles12;";
    //Listar Servicios
    public List<Servicio> obtener(string codServicio)
            {
                List<Servicio> Servicios = new List<Servicio>();
                Servicio serviciosencontrados = null;
                string sentencia = "SELECT * FROM Servicio where 1 = 1"; //codServicio = @codServicio";
                using (SqlConnection conexion = new SqlConnection(cadenaconexion))
                {
                    conexion.Open();
                    using (SqlCommand comando = new SqlCommand(sentencia, conexion))
                    {
                        //comando.Parameters.Add(new SqlParameter("@codServicio", codServicio));
                        using (SqlDataReader resultado = comando.ExecuteReader())
                        {
                            while (resultado.Read())
                            {
                                serviciosencontrados = new Servicio
                                {
                                    id = (int)resultado["id"],
                                    codServicio = (string)resultado["codServicio"],
                                    tipoServicio = (string)resultado["tipoServicio"],
                                    fechaServicio = (DateTime?)resultado["fechaServicio"],
                                    monto = (decimal?)resultado["monto"],
                                    obserServicio = (string)resultado["obserServicio"],
                                    detalleServicio = (string)resultado["detalleServicio"],
                                    departamento = (string)resultado["departamento"],
                                    ciudad = (string)resultado["ciudad"],
                                    distrito = (string)resultado["distrito"],
                                    direccion = (string)resultado["direccion"],
                                    idProfesional = (int?)resultado["idProfesional"],
                                    idCliente = (int?)resultado["idCliente"],
                                    imgUrl = (string)resultado["imgUrl"],
                                }; Servicios.Add(serviciosencontrados);
                            }
                        }
                    }
                }
                return Servicios;
            }

    //Agregar Servicios
    public Servicio agregar(Servicio servicio)
        {
            Servicio servicioCreado = null;
            try
            {

            string sentencia = "Insert into servicio (codServicio,tipoServicio,fechaServicio,monto,obserServicio,detalleServicio,departamento,ciudad,distrito,direccion,idProfesional,idCliente,imgUrl)" +
                                "values(@codServicio, @tipoServicio, @fechaServicio, @monto, @obserServicio, @detalleServicio, @departamento, @ciudad, @distrito, @direccion, @idProfesional, @idCliente, @imgUrl)";
            ;
            using (SqlConnection conexion = new SqlConnection(cadenaconexion))
            {
                conexion.Open();
                using (SqlCommand comando = new SqlCommand(sentencia, conexion))
                {

                    comando.Parameters.Add(new SqlParameter("@codServicio", servicio.codServicio));
                    comando.Parameters.Add(new SqlParameter("@tipoServicio", servicio.tipoServicio));
                    comando.Parameters.Add(new SqlParameter("@fechaServicio", DateTime.Now));
                    comando.Parameters.Add(new SqlParameter("@monto", servicio.monto));
                    comando.Parameters.Add(new SqlParameter("@obserServicio", servicio.obserServicio));
                    comando.Parameters.Add(new SqlParameter("@detalleServicio", servicio.detalleServicio));
                    comando.Parameters.Add(new SqlParameter("@departamento", servicio.departamento));
                    comando.Parameters.Add(new SqlParameter("@ciudad", servicio.ciudad));
                    comando.Parameters.Add(new SqlParameter("@distrito", servicio.distrito));
                    comando.Parameters.Add(new SqlParameter("@direccion", servicio.direccion));
                    comando.Parameters.Add(new SqlParameter("@idProfesional", servicio.idProfesional));
                    comando.Parameters.Add(new SqlParameter("@idCliente", servicio.idCliente));
                    comando.Parameters.Add(new SqlParameter("@imgUrl", servicio.imgUrl));
                    comando.ExecuteNonQuery();
                }
            }

            servicioCreado = obtener("1").Where(x => x.codServicio == servicio.codServicio).FirstOrDefault();
            return servicioCreado;
            }
            catch (Exception ex)
            {
                servicioCreado.detalleServicio = ex.ToString();
                return servicioCreado;
            }
        }


    }
}
