﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Twilio;
using Twilio.Rest.Api.V2010.Account;
using Twilio.Types;
using Twilio.TwiML;
using Twilio.AspNet.Mvc;
using ApiRestByCs.Dominio;
using ApiRestByCs.Persintencia;

namespace ApiRestByCs.Persintencia
{
    public class EnvioMensaje
    {
        //envio de mensaje
        public string enviarSMS(Solicitud obj)
        {
            {
                try
                {
                    var accounId = "AC51cef6ca8893061fe31ed7d03adb06af";// ConfigurationManager.AppSettings["AC51cef6ca8893061fe31ed7d03adb06af"];
                    var authToken = "c7357dc65ad7b947c7f7737379a394cb";//ConfigurationManager.AppSettings["c7357dc65ad7b947c7f7737379a394cb"];

                    TwilioClient.Init(accounId, authToken);

                    var to = new PhoneNumber("+51941446376");// numero destinatario 
                    var form = new PhoneNumber("+14582365341");



                    var mensaje = MessageResource.Create(
                        to: to,
                        from: form,
                        body:
                        "  Cliente:    " + obj.cliente.nombres + '-' + obj.cliente.apellidos + '-' + obj.cliente.direccion +

                       " -----" +
                       "   Profesional:  " + obj.profesional.nombres + '-' + obj.cliente.apellidos +
                          " -----" +
                       "    servicio: " + obj.tipoServicio + "   monto: " + obj.monto + "   detalle de servicio: " + obj.detalleServicio + 
                       "    estado:  " + obj.estado );

                    return mensaje.Sid;
                }
                catch (Exception ex)
                {

                    throw ex;
                }
            }
        }

    }
}
