﻿using ApiRestByCs.Dominio;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace ApiRestByCs.Persintencia
{
    public class SolicitudDAO
    {
        private string cadenaconexion = "Data Source=dbdemo.c8sweumaifih.us-east-2.rds.amazonaws.com;initial catalog=bdproyectoSyCs;User ID=admin;Password=Valles12;";
        //Registrar Solicitud

        public Solicitud agregar(Solicitud solicitud)
        {
            Solicitud solicitudCreado = null;
            string sentencia = "Insert into Solicitud (codSolicitud,tipoServicio,fechaSolicitud,monto,detalleServicio,distrito,direccion,idProfesional,idCliente)" +
                                "values(@codSolicitud, @tipoServicio, @fechaSolicitud, @monto, @detalleServicio, @distrito, @direccion, @idProfesional, @idCliente)";
            ;
            using (SqlConnection conexion = new SqlConnection(cadenaconexion))
            {
                conexion.Open();
                using (SqlCommand comando = new SqlCommand(sentencia, conexion))
                {

                    comando.Parameters.Add(new SqlParameter("@codSolicitud", solicitud.codSolicitud));
                    comando.Parameters.Add(new SqlParameter("@tipoServicio", solicitud.tipoServicio));
                    comando.Parameters.Add(new SqlParameter("@fechaSolicitud", solicitud.fechaSolicitud));
                    comando.Parameters.Add(new SqlParameter("@monto", solicitud.monto));
                    comando.Parameters.Add(new SqlParameter("@detalleServicio", solicitud.detalleServicio));
                    comando.Parameters.Add(new SqlParameter("@distrito", solicitud.distrito));
                    comando.Parameters.Add(new SqlParameter("@direccion", solicitud.direccion));
                    comando.Parameters.Add(new SqlParameter("@idProfesional", solicitud.idProfesional));
                    comando.Parameters.Add(new SqlParameter("@idCliente", solicitud.idCliente));
                    comando.ExecuteNonQuery();
                }
            }
            solicitudCreado = obtener("1").Where(x => x.codSolicitud == solicitud.codSolicitud).FirstOrDefault();
            return solicitudCreado;
        }

        //Listar Solicitud
        public List<Solicitud> obtener(string codSolicitud)
        {
            List<Solicitud> solicitud = new List<Solicitud>();
            Solicitud solicitudencontrados = null;
            string sentencia = "SELECT * FROM Solicitud where 1 = 1"; 
            using (SqlConnection conexion = new SqlConnection(cadenaconexion))
            {
                conexion.Open();
                using (SqlCommand comando = new SqlCommand(sentencia, conexion))
                {
                    
                    using (SqlDataReader resultado = comando.ExecuteReader())
                    {
                        while (resultado.Read())
                        {
                            solicitudencontrados = new Solicitud
                            {
                                id = (int)resultado["id"],
                                codSolicitud = (string)resultado["codSolicitud"],
                                tipoServicio = (string)resultado["tipoServicio"],
                                fechaSolicitud = (DateTime?)resultado["fechaSolicitud"],
                                monto = (decimal?)resultado["monto"],
                                detalleServicio = (string)resultado["detalleServicio"],
                                distrito = (string)resultado["distrito"],
                                direccion = (string)resultado["direccion"],
                                idProfesional = (int?)resultado["idProfesional"],
                                idCliente = (int?)resultado["idCliente"],
                            }; solicitud.Add(solicitudencontrados);
                        }
                    }
                }
            }
            return solicitud;
        }

        public Task<Response> registrarSolicitud(Solicitud obj)
        {
            Response oDatos = new Response();
            string[] vmensaje;

            using (var connection = new SqlConnection(cadenaconexion))
            {
                try
                {
                    connection.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandText = "LOG_InstSolicitud";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Connection = connection;
                    cmd.Parameters.AddWithValue("@idCliente", obj.idCliente );
                    cmd.Parameters.AddWithValue("@idusuario", obj.idProfesional);
                    cmd.Parameters.AddWithValue("@idServicio", obj.Idservicio);
                    cmd.Parameters.AddWithValue("@dt_fechSolicitud", obj.fechaSolicitud);
                    cmd.Parameters.AddWithValue("@user_create","admin");
                    SqlParameter RuturnValue = new SqlParameter("@Mensaje", SqlDbType.VarChar, 100);
                    RuturnValue.Direction = ParameterDirection.Output;
                    cmd.Parameters.Add(RuturnValue);
                    cmd.ExecuteReader();
                    string RequestStatus = (string)cmd.Parameters["@Mensaje"].Value;

                    vmensaje = RequestStatus.Split('|');
                    oDatos.Value = vmensaje[1];
                    oDatos.detalle = vmensaje[2];
                    oDatos.status = vmensaje[0];

                }
                catch (Exception ex)
                {
                    return (Task<Response>)Task.FromException(ex);
                }
            }
            return Task.FromResult(oDatos);
        }

        public Task<Solicitud> listaEnvio(int id)
        {
            Solicitud oData = null;
             
            try
            {
                using (SqlConnection connection= new SqlConnection(cadenaconexion))
                {
                    connection.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandText = "EnviarMensaje";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Connection = connection;
                    cmd.Parameters.AddWithValue("@id", id);
                    SqlDataReader reader = cmd.ExecuteReader();
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            oData = new Solicitud();
                            oData.cliente.nombres = reader["nombresCli"].ToString();
                            oData.cliente.apellidos = reader["apellidosCli"].ToString();
                            oData.cliente.direccion = reader["direccionCli"].ToString();


                            oData.profesional.nombres = reader["nombres"].ToString();
                            oData.profesional.apellidos = reader["apellidos"].ToString(); 

                            oData.tipoServicio= reader["tipoServicio"].ToString();
                            oData.monto=int.Parse(reader["monto"].ToString());
                            oData.detalleServicio= reader["detalleServicio"].ToString();
                            oData.estado= reader["estado"].ToString();
                            

                        }
                    }
                }
                return Task.FromResult(oData);
            }

            catch (Exception ex)
            {

                throw ex;
            }

        }



        public Task<List<Solicitud>> listaSolicitud(int id)
        {
            List<Solicitud> obj = new  List<Solicitud>();

            try
            {
                using (SqlConnection connection = new SqlConnection(cadenaconexion))
                {
                    connection.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandText = "listaServicio";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Connection = connection;
                    cmd.Parameters.AddWithValue("@id", id);
                    SqlDataReader reader = cmd.ExecuteReader();
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            Solicitud oData = new Solicitud();
                            oData.cliente.nombres = reader["nombresCli"].ToString();
                            oData.cliente.apellidos = reader["apellidosCli"].ToString();
                            oData.cliente.direccion = reader["direccionCli"].ToString();


                            oData.profesional.nombres = reader["nombres"].ToString();
                            oData.profesional.apellidos = reader["apellidos"].ToString();

                            oData.tipoServicio = reader["tipoServicio"].ToString();
                            oData.monto = int.Parse(reader["monto"].ToString());
                            oData.detalleServicio = reader["detalleServicio"].ToString();
                            oData.estado = reader["estado"].ToString();
                            obj.Add(oData);

                        }
                    }
                }
                return Task.FromResult(obj);
            }

            catch (Exception ex)
            {

                throw ex;
            }

        }


        public Task<Solicitud> obtenerSolicitud(int id)
        {
            Solicitud oData = null;

            try
            {
                using (SqlConnection connection = new SqlConnection(cadenaconexion))
                {
                    connection.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandText = "ObtenerServicio";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Connection = connection;
                    cmd.Parameters.AddWithValue("@id", id);
                    SqlDataReader reader = cmd.ExecuteReader();
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            oData = new Solicitud();
                            oData.cliente.nombres = reader["nombresCli"].ToString();
                            oData.cliente.apellidos = reader["apellidosCli"].ToString();
                            oData.cliente.direccion = reader["direccionCli"].ToString();


                            oData.profesional.nombres = reader["nombres"].ToString();
                            oData.profesional.apellidos = reader["apellidos"].ToString();

                            oData.tipoServicio = reader["tipoServicio"].ToString();
                            oData.monto = int.Parse(reader["monto"].ToString());
                            oData.detalleServicio = reader["detalleServicio"].ToString();
                            oData.estado = reader["estado"].ToString(); 
                        }
                    }
                }
                return Task.FromResult(oData);
            }

            catch (Exception ex)
            {

                throw ex;
            }

        }
    }
}
