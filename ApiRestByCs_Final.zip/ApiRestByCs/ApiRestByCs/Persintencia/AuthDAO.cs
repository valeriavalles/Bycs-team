﻿using ApiRestByCs.Dominio;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace ApiRestByCs.Persintencia
{
    public class AuthDAO
    { 

    private string cadenaconexion = "Data Source=dbdemo.c8sweumaifih.us-east-2.rds.amazonaws.com;initial catalog=bdproyectoSyCs;User ID=admin;Password=Valles12;";

        //Listar 
        public Auth obtener(Auth auth)
        {
            try
            {

            Auth objAuth = new Auth();
            List<UsuarioAuth> usuarios = new List<UsuarioAuth>();
            UsuarioAuth usuariosencontrados = null;
            string sentencia = "SELECT * FROM Usuario where 1 = 1"; 
            using (SqlConnection conexion = new SqlConnection(cadenaconexion))
            {
                conexion.Open();
                using (SqlCommand comando = new SqlCommand(sentencia, conexion))
                {
                    using (SqlDataReader resultado = comando.ExecuteReader())
                    {
                        while (resultado.Read())
                        {
                            usuariosencontrados = new UsuarioAuth
                            {
                                id = (int)resultado["id"],
                                nombres = (string)resultado["nombres"],
                                apellidos = (string)resultado["apellidos"],
                                correo = (string)resultado["correo"],
                                direccion = (string)resultado["direccion"],
                                tipousuario = (string)resultado["tipousuario"],
                                dni = (string)resultado["dni"],
                                numeroceltel = (string)resultado["numeroceltel"],
                                tiposervicio = (string)resultado["tiposervicio"],
                                password = (string)resultado["password"],
                            }; usuarios.Add(usuariosencontrados);
                        }
                    }
                }
            }
            if (usuarios.Count() > 0)
            {
                if (usuarios.FirstOrDefault().correo == auth.correo && usuarios.FirstOrDefault().password == auth.password)
                {
                    objAuth.correo = usuarios.FirstOrDefault().correo;
                    objAuth.tipoServicio = usuarios.FirstOrDefault().tiposervicio;
                    objAuth.nombres = usuarios.FirstOrDefault().nombres;
                    objAuth.apellidos = usuarios.FirstOrDefault().apellidos;
                    objAuth.estado = "1";
                    objAuth.id = usuarios.FirstOrDefault().id;
                    return objAuth;
                }
                else
                {
                    objAuth.correo = auth.correo;
                    objAuth.tipoServicio = " ";
                    objAuth.nombres = " ";
                    objAuth.apellidos = " ";
                    objAuth.estado = "0";
                    objAuth.id = 0;
                    return objAuth;
                }

            }
            else
            {
                objAuth.correo = auth.correo;
                objAuth.tipoServicio = " ";
                objAuth.nombres = " ";
                objAuth.apellidos = " ";
                objAuth.estado = "2";
                objAuth.id = 0;
                return objAuth;
            }

            }
            catch (Exception ex)
            {

                throw;
            }


        }

    }
}
