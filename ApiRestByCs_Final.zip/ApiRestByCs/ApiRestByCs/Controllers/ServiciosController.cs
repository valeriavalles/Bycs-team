﻿using ApiRestByCs.Dominio;
using ApiRestByCs.Errores;
using ApiRestByCs.Persintencia;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Threading.Tasks;
using UsuarioServiceReference;


namespace ApiRestByCs.Controllers
{
    [Route("api/servicio")]  //Ruta  para invocar   desde  la app que consume 
    [ApiController]
    public class ServiciosController : ControllerBase
    {

        private ServicioDAO servicioDAO = new ServicioDAO();
        // GET: api/Servicios
        [HttpGet]
        public List<Servicio> Get()
        {
            List<Servicio> servicios = servicioDAO.obtener("1");
            return servicios;
        }

        // POST: api/Regla de Negocio
        [HttpPost]
        public async Task<ServiciosValidator> Post(Servicio servicio)
        {
            int cantServicios = 0;
            ServiciosValidator objValidator = new ServiciosValidator();
            cantServicios =  servicioDAO.obtener(" ").Where(x => x.idProfesional == servicio.idProfesional).Count();
            if (cantServicios >= 3)
            {
                objValidator.codigomensaje = "99";
                objValidator.mensaje = "Usted ya cuenta con 3 servicios registrado, para seguir registrando cambie su plan ";
            }
            else
            {
                Servicio objServicio = servicioDAO.agregar(servicio);
                objValidator.id = objServicio.id;
                objValidator.codServicio = objServicio.codServicio;
                objValidator.tipoServicio = objServicio.tipoServicio;
                objValidator.fechaServicio = objServicio.fechaServicio;
                objValidator.monto = objServicio.monto;
                objValidator.obserServicio = objServicio.obserServicio;
                objValidator.detalleServicio = objServicio.detalleServicio;
                objValidator.departamento = objServicio.departamento;
                objValidator.ciudad = objServicio.ciudad;
                objValidator.distrito = objServicio.distrito;
                objValidator.direccion = objServicio.direccion;
                objValidator.idProfesional = objServicio.idProfesional;
                objValidator.idCliente = objServicio.idCliente;
                objValidator.imgUrl = objServicio.imgUrl;
                objValidator.codigomensaje = "00";
                objValidator.mensaje = "Registrado correctammente";
            }
            
            return objValidator;
        }

    }
}
