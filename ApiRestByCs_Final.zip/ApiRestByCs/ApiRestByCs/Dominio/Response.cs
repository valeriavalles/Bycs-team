﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ApiRestByCs.Dominio
{
    public class Response
    {
        public string Value { get; set; }
        public string status { get; set; }
        public string detalle { get; set; }

    }
}
