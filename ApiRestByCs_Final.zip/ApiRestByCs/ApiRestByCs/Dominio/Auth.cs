﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ApiRestByCs.Dominio
{
    public class Auth
    {
        public int id { get; set; }
        public string correo { get; set; }
        public string password { get; set; }
        public string tipoServicio { get; set; }
        public string estado { get; set; }
        public string nombres { get; set; }
        public string apellidos { get; set; }




    }
}
